import React from 'react'

export default function AllProductsPage() {
  return (
    <div>AllProductsPage</div>
  )
}
