import React from 'react'

export default function ProductPage() {
  return (
    <div>ProductPage</div>
  )
}
