import React from 'react'

export default function CategoryPage() {
  return (
    <div>CategoryPage</div>
  )
}
