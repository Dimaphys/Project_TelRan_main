import React from 'react'

export default function ProductsFromCategoryPage() {
  return (
    <div>ProductsFromCategoryPage</div>
  )
}
